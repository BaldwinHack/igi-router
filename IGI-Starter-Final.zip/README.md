# IGI Starter (Final)

**Infinity Gold Intelligence – Multi‑LLM Router Foundation**

This repository is a clean, runnable baseline for a multi‑model AI router
supporting:
- Code generation
- Intelligence analysis
- Defensive cybersecurity guidance

## Run locally
```bash
docker compose up --build
```

## Core idea
- `router/` → routing, policy, safety
- `prompts/` → system doctrine
- `infra/` → deployment
- `.github/` → CI foundation
