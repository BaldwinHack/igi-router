from router.router import route_request

def main():
    print("IGI Router online")
    demo = route_request(
        task_type="analysis",
        payload="Provide a high-level risk assessment."
    )
    print(demo)

if __name__ == "__main__":
    main()
