MODEL_POLICY = {
    "code": "Qwen2.5-Coder-32B-Instruct",
    "analysis": "Llama-3.1-70B-Instruct",
    "defense": "Llama-3.1-70B-Instruct"
}

def select_model(task_type: str) -> str:
    """
    Deterministic policy-based model selection.
    """
    return MODEL_POLICY.get(task_type, MODEL_POLICY["analysis"])
