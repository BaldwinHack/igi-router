ALLOWED_TASKS = {"code", "analysis", "defense"}
BLOCKLIST = {"exploit", "weaponize", "malware", "backdoor"}

def enforce_guardrails(task_type: str, payload: str) -> None:
    if task_type not in ALLOWED_TASKS:
        raise ValueError(f"Task '{task_type}' is not permitted")

    lowered = payload.lower()
    for term in BLOCKLIST:
        if term in lowered:
            raise ValueError("Request blocked by defense guardrails")
