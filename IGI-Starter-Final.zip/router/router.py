from router.policy import select_model
from router.guardrails import enforce_guardrails

def route_request(task_type: str, payload: str) -> dict:
    """
    Core routing primitive.
    Validates request, selects model, returns routing decision.
    """
    enforce_guardrails(task_type, payload)
    model = select_model(task_type)

    return {
        "task_type": task_type,
        "model": model,
        "payload": payload
    }
