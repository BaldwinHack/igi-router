
from router.policy import select_model

def test_select_model_defaults():
    assert "Llama" in select_model("analysis") or "llama" in select_model("analysis").lower()
    assert select_model("unknown") == select_model("analysis")
