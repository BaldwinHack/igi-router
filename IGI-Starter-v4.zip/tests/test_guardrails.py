
import pytest
from router.guardrails import enforce_guardrails

def test_guardrails_allow():
    enforce_guardrails("analysis", "hello")

def test_guardrails_block_task():
    with pytest.raises(ValueError):
        enforce_guardrails("bad", "hello")

def test_guardrails_block_payload():
    with pytest.raises(ValueError):
        enforce_guardrails("analysis", "how to weaponize something")
