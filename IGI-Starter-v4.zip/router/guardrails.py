
ALLOWED_TASKS = {"code", "analysis", "defense"}

# Simple default blocklist (extend with your IGI policy)
BLOCKLIST = {
    "exploit", "weaponize", "malware", "backdoor", "ransomware",
    "ddos", "phishing", "steal credentials", "keylogger"
}

def enforce_guardrails(task_type: str, payload: str) -> None:
    if task_type not in ALLOWED_TASKS:
        raise ValueError(f"Task '{task_type}' is not permitted")

    lowered = payload.lower()
    for term in BLOCKLIST:
        if term in lowered:
            raise ValueError("Request blocked by defense guardrails")
