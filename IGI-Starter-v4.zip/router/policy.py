
# Deterministic routing policy (edit to taste)
MODEL_POLICY = {
    "code": "Qwen/Qwen2.5-Coder-32B-Instruct",
    "analysis": "meta-llama/Llama-3.1-70B-Instruct",
    "defense": "meta-llama/Llama-3.1-70B-Instruct",
}

def select_model(task_type: str) -> str:
    return MODEL_POLICY.get(task_type, MODEL_POLICY["analysis"])
