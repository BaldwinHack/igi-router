
import os
import json
import time
import requests

HF_TOKEN = os.getenv("HF_TOKEN", "").strip()
HF_TIMEOUT = float(os.getenv("HF_TIMEOUT", "60"))
HF_MAX_RETRIES = int(os.getenv("HF_MAX_RETRIES", "2"))

def _headers():
    if not HF_TOKEN:
        return {"Accept": "application/json"}
    return {"Authorization": f"Bearer {HF_TOKEN}", "Accept": "application/json"}

def _post(url: str, payload: dict):
    last_err = None
    for i in range(HF_MAX_RETRIES + 1):
        try:
            r = requests.post(url, headers=_headers(), json=payload, timeout=HF_TIMEOUT)
            if r.status_code == 503 and i < HF_MAX_RETRIES:
                # model loading / temporary — backoff
                time.sleep(1.5 * (i + 1))
                continue
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_err = e
            time.sleep(0.5)
    raise RuntimeError(f"HF request failed: {last_err}")

def hf_generate(model_id: str, prompt: str) -> dict:
    """Call HF Inference API for text generation. Returns a stub if HF_TOKEN is missing."""
    if not HF_TOKEN:
        return {
            "mode": "stub",
            "note": "Set HF_TOKEN in .env to enable live generation.",
            "text": "[stubbed-response]"
        }

    url = f"https://api-inference.huggingface.co/models/{model_id}"
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": int(os.getenv("HF_MAX_NEW_TOKENS", "256")),
            "temperature": float(os.getenv("HF_TEMPERATURE", "0.2")),
            "top_p": float(os.getenv("HF_TOP_P", "0.95")),
            "return_full_text": False,
        }
    }

    data = _post(url, payload)

    # HF output formats vary by pipeline; normalize lightly
    if isinstance(data, list) and data and isinstance(data[0], dict) and "generated_text" in data[0]:
        return {"mode": "hf", "text": data[0]["generated_text"]}
    return {"mode": "hf", "raw": data}

def hf_embed(model_id: str, texts: list[str]) -> list[list[float]]:
    """Call HF for embeddings (works best with TEI-compatible embedding models)."""
    if not HF_TOKEN:
        raise RuntimeError("HF_TOKEN required for embeddings. Set it in .env")

    url = f"https://api-inference.huggingface.co/models/{model_id}"
    payload = {"inputs": texts}
    data = _post(url, payload)

    # Many embedding endpoints return list[list[float]]
    if isinstance(data, list) and data and isinstance(data[0], list):
        return data
    # Some return dict with 'embeddings'
    if isinstance(data, dict) and "embeddings" in data:
        return data["embeddings"]
    raise RuntimeError(f"Unexpected embedding response: {type(data)}")
