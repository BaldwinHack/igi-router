
from router.policy import select_model
from router.guardrails import enforce_guardrails
from router.hf_client import hf_generate

def route_request(task_type: str, payload: str, context=None) -> dict:
    """Validate, select model, and optionally call HF for generation."""
    enforce_guardrails(task_type, payload)
    model = select_model(task_type)

    prompt = payload
    if context:
        # Keep it simple: add top context snippets
        ctx = "\n\n".join([f"- {h['text']}" for h in context])
        prompt = f"Context:\n{ctx}\n\nUser:\n{payload}"

    # For v4, we return both the routing decision and (optional) model output.
    # If HF is not configured, hf_generate returns a graceful stub.
    output = hf_generate(model_id=model, prompt=prompt)

    return {
        "task_type": task_type,
        "model": model,
        "prompt": prompt,
        "output": output,
    }
