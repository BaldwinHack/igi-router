
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from router.router import route_request
from rag.store import VectorStore
from rag.rag import rag_search, rag_upsert

class RouteIn(BaseModel):
    task_type: str
    payload: str
    use_rag: bool = False
    top_k: int = 5

class UpsertIn(BaseModel):
    ids: list[str]
    texts: list[str]
    metadatas: list[dict] | None = None

class SearchIn(BaseModel):
    query: str
    top_k: int = 5

def create_app() -> FastAPI:
    app = FastAPI(title="IGI Router", version="0.4.0")
    store = VectorStore()

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.post("/route")
    def route(inp: RouteIn):
        try:
            context = None
            if inp.use_rag:
                hits = rag_search(store=store, query=inp.payload, top_k=inp.top_k)
                context = hits
            decision = route_request(task_type=inp.task_type, payload=inp.payload, context=context)
            return decision
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/rag/upsert")
    def upsert(inp: UpsertIn):
        try:
            rag_upsert(store=store, ids=inp.ids, texts=inp.texts, metadatas=inp.metadatas)
            return {"status": "ok", "count": len(inp.ids)}
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.post("/rag/search")
    def search(inp: SearchIn):
        return {"hits": rag_search(store=store, query=inp.query, top_k=inp.top_k)}

    return app
