
# IGI Starter (v4)

Multi-LLM Router + HF client + RAG (embeddings + rerank) + minimal API.

## What’s new vs v3/final
- **HF client**: unified calls to Hugging Face Inference API / Endpoints
- **Router API**: FastAPI endpoint to route tasks
- **RAG module**: embeddings + rerank + tiny local vector store (JSONL) for “Codex memory”
- **Secrets hygiene**: `.env.example`
- **CI**: syntax + unit tests

## Quick start (Docker)
```bash
docker compose up --build
```
Then open:
- `GET http://localhost:8000/health`
- `POST http://localhost:8000/route`
- `POST http://localhost:8000/rag/upsert`
- `POST http://localhost:8000/rag/search`

## Environment
Copy `.env.example` → `.env` and set:
- `HF_TOKEN` (recommended)
- model IDs or endpoint URLs

## Safety note
This foundation is tuned for **lawful analysis, programming, and defensive security**.
The guardrails block obvious malicious keywords by default; expand as needed.
