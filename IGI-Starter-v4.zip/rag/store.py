
import os
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any
import numpy as np

STORE_PATH = Path(os.getenv("IGI_RAG_STORE", "rag_store.jsonl"))
EMBED_MODEL = os.getenv("IGI_EMBED_MODEL", "BAAI/bge-m3")

@dataclass
class Item:
    _id: str
    text: str
    metadata: dict[str, Any]
    vector: list[float]

class VectorStore:
    """Tiny local JSONL vector store for bootstrap RAG."""
    def __init__(self, path: Path = STORE_PATH):
        self.path = path
        self.items: list[Item] = []
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                d = json.loads(line)
                self.items.append(Item(**d))

    def upsert(self, items: list[Item]):
        # naive: append; for real use, replace by id
        existing = {it._id for it in self.items}
        for it in items:
            if it._id in existing:
                self.items = [x for x in self.items if x._id != it._id]
            self.items.append(it)
        self._persist()

    def _persist(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as f:
            for it in self.items:
                f.write(json.dumps({
                    "_id": it._id,
                    "text": it.text,
                    "metadata": it.metadata,
                    "vector": it.vector
                }) + "\n")

    def search(self, query_vec: list[float], top_k: int = 5):
        if not self.items:
            return []
        q = np.array(query_vec, dtype=np.float32)
        q = q / (np.linalg.norm(q) + 1e-9)

        mats = np.array([it.vector for it in self.items], dtype=np.float32)
        mats = mats / (np.linalg.norm(mats, axis=1, keepdims=True) + 1e-9)

        sims = mats @ q
        idx = np.argsort(-sims)[:top_k]
        hits = []
        for i in idx:
            it = self.items[int(i)]
            hits.append({
                "id": it._id,
                "score": float(sims[int(i)]),
                "text": it.text,
                "metadata": it.metadata,
            })
        return hits
