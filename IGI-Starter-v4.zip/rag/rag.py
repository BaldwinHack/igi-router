
from typing import Any
from rag.store import VectorStore, Item, EMBED_MODEL
from router.hf_client import hf_embed

def rag_upsert(store: VectorStore, ids: list[str], texts: list[str], metadatas: list[dict] | None = None):
    if len(ids) != len(texts):
        raise ValueError("ids and texts length mismatch")
    if metadatas is None:
        metadatas = [{} for _ in ids]
    if len(metadatas) != len(ids):
        raise ValueError("metadatas length mismatch")

    vecs = hf_embed(model_id=EMBED_MODEL, texts=texts)
    items = []
    for _id, text, md, vec in zip(ids, texts, metadatas, vecs):
        items.append(Item(_id=_id, text=text, metadata=md, vector=vec))
    store.upsert(items)

def rag_search(store: VectorStore, query: str, top_k: int = 5):
    vec = hf_embed(model_id=EMBED_MODEL, texts=[query])[0]
    return store.search(query_vec=vec, top_k=top_k)
