
import os
import requests

BASE = os.getenv("IGI_BASE", "http://localhost:8000")

payload = {
  "task_type": "analysis",
  "payload": "Write a short IGI-style briefing on supply chain risk.",
  "use_rag": True,
  "top_k": 3
}

r = requests.post(f"{BASE}/route", json=payload, timeout=120)
print(r.status_code)
print(r.json())
