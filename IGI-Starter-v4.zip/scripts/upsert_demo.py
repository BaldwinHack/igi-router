
import os
import requests

BASE = os.getenv("IGI_BASE", "http://localhost:8000")

payload = {
  "ids": ["codex-001", "codex-002"],
  "texts": [
    "IGI Router selects models based on task_type: code, analysis, defense.",
    "RAG uses embeddings (bge-m3) to retrieve relevant doctrine snippets."
  ],
  "metadatas": [{"source": "demo"}, {"source": "demo"}]
}

r = requests.post(f"{BASE}/rag/upsert", json=payload, timeout=60)
print(r.status_code, r.text)
